import { EmployeeDetailsPage } from './app.po';

describe('employee-details App', () => {
  let page: EmployeeDetailsPage;

  beforeEach(() => {
    page = new EmployeeDetailsPage();
  });

  it('should display welcome message', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('Welcome to app!');
  });
});
