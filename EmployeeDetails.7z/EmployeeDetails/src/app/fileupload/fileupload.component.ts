import { Component, OnInit } from '@angular/core';
import { Headers, RequestOptions } from '@angular/http';

import { RestService } from "../rest.service";
@Component({
  selector: 'app-fileupload',
  templateUrl: './fileupload.component.html',
  styleUrls: ['./fileupload.component.css']
})
export class FileuploadComponent implements OnInit {

  constructor(private restService: RestService) { }
  fileList: FileList = null;
  url = '';
  fileName = '';
  ngOnInit() {
  }

  fileSelectedEvent(event) {
    this.fileList = event.target.files;
    console.log('FF' + this.fileList);

    this.fileName = 'Selected File : ' + this.fileList[0].name;
  }

  uploadFile() {
    if (this.fileList.length > 0) {
      const file: File = this.fileList[0];
      console.log(file);
      console.log(file.name);
      const formData: FormData = new FormData();
      formData.append('xls', file, file.name);
      const headers = new Headers();
      headers.append('enctype', 'multipart/form-data');
      const options = new RequestOptions({ headers: headers });
      this.url = '' + this.restService.getServiceUrl('upload');
      this.restService.invokeUploadFileService(this.url, formData, options);
    }
  }

}
