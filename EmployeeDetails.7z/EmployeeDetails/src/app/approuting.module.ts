import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { EmployeedetailsComponent } from './employeedetails/employeedetails.component';

const routes: Routes = [
    { path: '', redirectTo: '/app/0', pathMatch: 'full' },
    {
        path: 'app/:id', component: EmployeedetailsComponent
    },
    { component: EmployeedetailsComponent, path: '**' }
];

@NgModule({
    declarations: [],
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule],
    providers: [],
})
export class AppRoutingModule { }
