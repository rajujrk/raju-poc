import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpModule } from '@angular/http';

import { RestService } from './rest.service';

import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { LeftpanelComponent } from './leftpanel/leftpanel.component';
import { EmployeedetailsComponent } from './employeedetails/employeedetails.component';
import { ContactdetailsComponent } from './contactdetails/contactdetails.component';
import { ContentComponent } from './content/content.component';


import { AppRoutingModule } from './approuting.module';
import { DahsboardComponent } from './dahsboard/dahsboard.component';
import { ListEmployeesComponent } from './list-employees/list-employees.component';
import { FileuploadComponent } from './fileupload/fileupload.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    LeftpanelComponent,
    EmployeedetailsComponent,
    ContactdetailsComponent,
    ContentComponent,
    DahsboardComponent,
    ListEmployeesComponent,
    FileuploadComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpModule
  ],
  providers: [RestService],
  bootstrap: [AppComponent]
})
export class AppModule { }
