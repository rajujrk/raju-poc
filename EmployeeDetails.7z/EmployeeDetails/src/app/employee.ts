export class Employee {

    empId: number;
    empName: string;
    doj: string;
    jobTitle: string;
    department: string;
    company: string;
    city: string;
    country: string;
    email: string;
    phone: string;
    thumbImg: string;
    objectId: string;

    constructor(empId: number, empName: string, doj: string, jobTitle: string, department: string, company: string, city: string, country: string, email: string, phone: string, thumbImg: string, objectId: string) {
        this.empId = empId;
        this.empName = empName;
        this.doj = doj;
        this.jobTitle = jobTitle;
        this.department = department;
        this.company = company;
        this.city = city;
        this.country = country;
        this.email = email;
        this.phone = phone;
        this.thumbImg = thumbImg;
        this.objectId = objectId;
    }
}
