import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { RestService } from '../rest.service';

import { Employee } from '../employee';
@Component({
  selector: 'app-employeedetails',
  templateUrl: './employeedetails.component.html',
  styleUrls: ['./employeedetails.component.css']
})
export class EmployeedetailsComponent implements OnInit {

  constructor(private route: ActivatedRoute, private restService: RestService) { }
  empId = '';
  emp: Employee = null;
  url = '';
  ngOnInit() {
    this.route.params.subscribe(
      p => {
        this.empId = '' + p['id'];
        if (this.empId !== '' && this.empId !== '0') {
          console.log(this.empId);
          this.url = '' + this.restService.getServiceUrl('searchid');

          this.restService.invokeGetService(this.url, this.empId).subscribe(
            data => {
              console.log(data);
              if (data.status || data.status === 'true') {
                const result = data.empDetails;
                console.log('Result:: ' + data.empDetails);
                this.emp = new Employee(result.empId, result.empName, result.doj, result.jobTitle, result.department, result.company, result.city, result.country, result.email, result.phone, result.thumbImg, result.id);
                console.log(this.emp);

              }
              // console.log(this.employeeList);
            },
            err => console.log('err==>' + err),
            () => console.log('Completed')
          );
        } else {
          this.emp = new Employee(0, '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-');
        }
      });
  }

}
