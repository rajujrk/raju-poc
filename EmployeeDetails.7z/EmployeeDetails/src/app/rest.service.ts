import { Injectable, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Http, Response } from '@angular/http';

import 'rxjs/add/operator/map';

import { Observable } from 'rxjs/Rx';

@Injectable()
export class RestService implements OnInit {

  serviceUrls = {
    'create': 'http://localhost:9000/createEmployee/',
    'update': 'http://localhost:9000/updateEmployee/',
    'delete': 'http://localhost:9000/deleteEmployee?empId=',
    'list': 'http://localhost:9000/listEmployees/',
    'search': 'http://localhost:9000/searchEmployee?empName=',
    'upload': 'http://localhost:9000/updalodExcel',
    'searchid': 'http://localhost:9000/searchEmployeeById?empId='
  };
  constructor(private http: Http, private router: Router) { }
  ngOnInit() { }

  getServiceUrl(urlKey) {

    return this.serviceUrls[urlKey];

  }
  invokeGetService(service, argument) {
    if (argument !== null && argument !== '') {
      service = service + '' + argument;
    }

    console.log('serv:: ' + service);

    return this.http.get(service).map((res: Response) => res.json());
  }

  invokePostService(service, argument: any) {

    return this.http.post(service, JSON.stringify(argument)).map((res: Response) => res.json());
  }
  invokeUploadFileService(service, formData: any, options: any) {
    this.http.post(service, formData, options)
      .map(res => res.json())
      .catch(error => Observable.throw(error))
      .subscribe(
      data => {
        console.log(data);
      },
      error => {
        console.log(error);
      }
      );
  }
  invokeDeleteService(service, argument: any) {
    if (argument !== null && argument !== '') {
      service = service + '' + argument;
    }

    return this.http.delete(service).map((res: Response) => res.json());
  }
}
