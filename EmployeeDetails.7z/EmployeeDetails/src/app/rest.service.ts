import { Injectable, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Http, Response } from '@angular/http';

import 'rxjs/add/operator/map';

@Injectable()
export class RestService implements OnInit {

  serviceUrls = {
    'create': 'http://localhost:9000/createEmployee/',
    'update': 'http://localhost:9000/updateEmployee/',
    'delete': 'http://localhost:9000/deleteEmployee?empId=',
    'list': 'http://localhost:9000/listEmployees/',
    'search': 'http://localhost:9000/searchEmployee',
    'upload': 'http://localhost:9000/updalodExcel'
  };
  constructor(private http: Http, private router: Router) { }
  ngOnInit() { }

  getServiceUrl(urlKey) {

    return this.serviceUrls[urlKey];

  }
  invokeGetService(service, argument) {
    if (argument !== null && argument !== '') {
      service = service + '' + argument;
    }

    return this.http.get(service).map((res: Response) => res.json());
  }

  invokePostService(service, argument: any) {

    return this.http.post(service, JSON.stringify(argument)).map((res: Response) => res.json());
  }

  invokeDeleteService(service, argument: any) {
    if (argument !== null && argument !== '') {
      service = service + '' + argument;
    }

    return this.http.delete(service).map((res: Response) => res.json());
  }
}
