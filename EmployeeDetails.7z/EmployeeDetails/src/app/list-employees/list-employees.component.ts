import { Component, OnInit } from '@angular/core';
import { RestService } from '../rest.service';

import { Employee } from '../employee';
@Component({
  selector: 'app-list-employees',
  templateUrl: './list-employees.component.html',
  styleUrls: ['./list-employees.component.css']
})
export class ListEmployeesComponent implements OnInit {

  constructor(private restService: RestService) { }
  url = '';
  employeeList: Employee[] = [];
  ngOnInit() {
    this.url = '' + this.restService.getServiceUrl('list');

    this.restService.invokeGetService(this.url, null).subscribe(
      data => {
        console.log(data.status);
        if (data.status || data.status === 'true') {
          for (const result of data.employeeList) {
            this.employeeList.push(new Employee(result.empId, result.empName, result.doj, result.jobTitle, result.department, result.company, result.city, result.country, result.email, result.phone, result.thumbImg, result.id));
          }

        }
        console.log(this.employeeList);
      },
      err => console.log('err==>' + err),
      () => console.log('Completed')
    );
  }

}
