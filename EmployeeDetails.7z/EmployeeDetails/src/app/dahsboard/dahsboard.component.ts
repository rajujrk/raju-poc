import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dahsboard',
  templateUrl: './dahsboard.component.html',
  styleUrls: ['./dahsboard.component.css']
})
export class DahsboardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
